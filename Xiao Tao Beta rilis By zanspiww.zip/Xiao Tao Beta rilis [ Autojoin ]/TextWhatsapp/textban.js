


exports.textbanv1 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Porfavor,desative o número da minha conta ,o chip e os documentos foram roubados essa conta possuí dados importante, então, por favor desative minha conta [+62 XXX-XXXX-XXXX]
`
}
//------------------------------------------------------------------\\
exports.textbanv2 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, perdi meu dispositivo recentemente e preciso desativar minha conta do whatsapp até comprar um novo sim! meu número é (+62xxx)
`
}
//------------------------------------------------------------------\\
exports.textbanv3 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Ola, por favor desative este numero, pois perdi meu telefone e alguem esta usando meu numero, por favor desative meu numero : [+62 xxxx ]
`
}
//------------------------------------------------------------------\\
exports.textbanv4 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Hello, I was robbed 1 day ago and I lost all my data documents I lost everything, my cell phone, my documents, my money, so I ask urgently for the whatsapp team to deactivate my urgent account number: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv5 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá equipe de suporte do WhatsApp, alguém pediu o código de verificação errado para o meu número e eu fui desconectado e agora não consigo mais entrar na minha conta porque me pediu para esperar algumas horas, mas preciso acessar minha conta o mais rápido possível. para redefinir o código de verificação para meu número meu número é: (+628xxx)
`
}
//------------------------------------------------------------------\\
exports.textbanv6 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, esse número ( +628xxx ) está comendo assédios a menores de idade, e eu fui alvo desse crime de abuso sexual, por isso peço para a equipe de suporte do whatsapp banir esse número urgênte Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv7 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, minha filha de 11 anos está sendo alvo de um crime de abuso sexual, este número ( +628xxx ) está pedindo foto intimas dela desde ontem.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv8 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, este usuário do whatsapp está usando uma foto de perfil para manor de -18, por isso peço pelos, direitos do consumidor do usuário do whatsapp que esse número seja banido imediatamente.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv9 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, eu trabalho como vendedora online, hoje eu estava trabalhando como qualquer dia comum, até que um cliente me enviou uma foto íntima eu reconheci, aquela foto era de um menor de idade, por isso peço para a equipe do whatsapp banir este número urgênte, para que ele não cometa mais esse crimes.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv10 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, sou novato no aplicativo whatsapp, e logo hoje no primeiro dia eu percebi que um usuário que usava uma outra versão modificada do whatsapp, por isso fiz essa denúncia espero que a equipe do whatsapp faça oque a sua obrigação banir este número ( +628xxx ) pois esse usuário este violando a privacidade do whatsapp.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv11 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, Este número está espalhando fotos intimas minhas para muito grupos do whatsapp, por isso peço para a equipe de suporte do whatsapp banir urgênte este número, pois ele este violando as lei da privacidade do whatsapp.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv12 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Hello, I was robbed 1 day ago and I lost all my data documents I lost everything, my cell phone, my documents, my money, so I ask urgently for the whatsapp team to deactivate my urgent account number: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv13 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Tirem meu número do whatsapp, não irei mas usa este número por isso peço para a equipe de suporte banir meu número.Número: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv14 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá, minha conta foi banida e não estou conseguindo recupera, peço para a equipe de suporte do whatsapp desbanir minha conta pois preciso dela para assunto de trabalho.Não consigo acessa minha conta.numero: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv15 = (prefix) => {
return `please deactivate my account +628xxx .Many thanks
`
}
//------------------------------------------------------------------\\
exports.textbanv16 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا ، تم حظر حسابي ولا يمكنني استعادته ، أطلب من فريق دعم whatsapp إلغاء حظر حسابي لأنني بحاجة إليه للعمل ، ولا يمكنني الوصول إلى حسابي.

رقمي : +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv17 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا ، هذا الرقم ينشر صوري الحميمة للعديد من مجموعات الواتس اب ، لذا أطلب من فريق دعم واتس اب حظر هذا الرقم بشكل عاجل ، لأنه ينتهك قوانين الخصوصية.

رقمي : +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv18 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : خذ رقم whatsapp الخاص بي بعيدًا ، لن أذهب ولكن استخدم هذا الرقم لذا أطلب من فريق الدعم حظر رقمي. رقم: +62xxxxxxxxx
`
}
//------------------------------------------------------------------\\
exports.textbanv19 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا ، لقد تعرضت للسرقة منذ يوم واحد وفقدت جميع مستندات البيانات الخاصة بي وفقدت كل شيء وهاتفي الخلوي ووثائقي وأموالي ، لذلك أطلب بشكل عاجل من فريق whatsapp إلغاء تنشيط رقم حسابي العاجل: +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv20 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا ، هذا الرقم ينشر صوري الحميمة للعديد من مجموعات الواتس اب ، لذا أطلب من فريق دعم واتس اب حظر هذا الرقم بشكل عاجل ، لأنه ينتهك قوانين الخصوصية.

رقمي : +628xxx
`
}
//------------------------------------------------------------------\\
exports.textbanv21 = (prefix) => {
return `esse número foi banido porque ele estava nu na minha frente seu pau preto Número: +62xxxxxxx
`
}
//------------------------------------------------------------------\\
exports.textbanv22 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : Ban رقم الحساب هذا (+628xxx) على الفور لأنه بريد عشوائي
`
}
//------------------------------------------------------------------\\
exports.textbanv23 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Ban este número de conta (+628xxx) imediatamente porque é spam
`
}
//------------------------------------------------------------------\\
exports.textbanv24 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا فريق دعم WhatsApp ، طلب شخص ما رمز التحقق الخاطئ لرقمي وانقطع الاتصال والآن لا يمكنني تسجيل الدخول إلى حسابي بعد الآن لأنه طلب مني الانتظار بضع ساعات ولكني بحاجة إلى الوصول إلى حسابي في أسرع وقت ممكن. لإعادة تعيين رمز التحقق إلى رقمي ، رقمي هو: (+628xxx)`
}
//------------------------------------------------------------------\\
exports.textbanv25 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Olá equipe de suporte do WhatsApp, alguém pediu o código de verificação errado para o meu número e eu fui desconectado e agora não consigo mais entrar na minha conta porque me pediu para esperar algumas horas, mas preciso acessar minha conta o mais rápido possível. para redefinir o código de verificação para meu número meu número é: (+628xxx)`
}

//------------------------------------------------------------------\\
exports.textbanv26 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Nomor hilang/dicuri tolong nonaktifkan nomor saya: +62xxxx

pesan : whatsapp tolong nonaktifkan nomor saya: +62xxx dikarenakan ponsel saya hilang dan semua data data kerja saya ada di akun whatsapp itu, jadi saya mohon kepada pihak whatsapp untuk segera menonaktifkan nomor whatsapp saya sesegera mungkin dikarenakan saya takut seseorang mengakses akun whatsapp saya lalu disalah gunakan, terimakasih.`
}
//------------------------------------------------------------------\\
exports.textbanv27 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Perdido/Roubado: Por favor, desative minha conta

Olá, por favor desative este número, pois perdi meu celular e alguém está usando meu número, por favor desative meu número: [+62xxxxxx] `
}

//------------------------------------------------------------------\\
exports.textbanv28 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : UM DE SEUS USUÁRIOS, ESTA USANDO O APK DO WHATSAPP FEITO POR TERCEIROS E ESTA INDO CONTRA OS TERMOS DE SERVIÇO PEÇO QUE ANALISEM ESSE USUÁRIO ( +62 ) `
}

//------------------------------------------------------------------\\
exports.textbanv29 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Esse número vem fazendo discurso ao ódio e divulgado conteúdo de porno infantil
Numero: +62xnxx  `
}

//------------------------------------------------------------------\\
exports.textbanv30 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Ol谩, por favor desative este n煤mero, 
pois perdi meu celular e algu茅m est谩 usando meu n煤mero, 
por favor desative meu n煤mero: [62xxxx] `
}

//------------------------------------------------------------------\\
exports.textbanv31 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Desative o número da minha conta [+62 XXX-XXXX-XXXX] imediatamente porque o número foi perdido`
}
//------------------------------------------------------------------\\
exports.textbanv32 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Porfavor,desative o número da minha conta ,o chip e os documentos foram roubados essa conta possuí dados importante, então, por favor desative minha conta [+62 XXX-XXXX-XXXX]`
}

//------------------------------------------------------------------\\
exports.textbanv33 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : الرجاء إلغاء تنشيط رقمي : 628xxx

Pesan : مرحبًا ، يرجى إلغاء تنشيط هذا الرقم ، لأنني فقدت هاتفي وشخص ما يستخدم رقمي ، يرجى إلغاء تنشيط رقمي: [+62xxx]`
}

//------------------------------------------------------------------\\
exports.textbanv34 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Hello, please deactivate this number, because I have lost my cellphone and someone is using my number, please deactivate my number: [+62xxxxxx]`
}

//------------------------------------------------------------------\\
exports.textbanv35 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Hello WhatsApp team, I found a number that has deliberately provided porn links, and he sent pornographic photos, I have blocked the contact, but I'm uncomfortable because he has so many numbers, and one of them is +62xxxx, that number often sends videos or porn pics, please deactivate the number, I beg you`
}

//------------------------------------------------------------------\\
exports.textbanv36 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : שלום צוות וואטסאפ, מצאתי מספר שסיפק בכוונה קישורים לפורנו, והוא שלח תמונות פורנוגרפיות, חסמתי את איש הקשר, אבל אני מרגיש לא בנוח כי יש לו כל כך הרבה מספרים, ואחד מהם הוא +62xxxx, המספר הזה לעתים קרובות שולח סרטונים או תמונות פורנו, אנא השבת את המספר, אני מתחנן בפניך`
}

//------------------------------------------------------------------\\
exports.textbanv37 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Por favor, desactive mi número : 628xxx

Pesan : Ban este número de conta (+628xxx) imediatamente porque é spam`
}
//------------------------------------------------------------------\\
exports.textbanv38 = (prefix) => {
return `Kepada : Support@support.whatsapp.com
Subjek : Please Deactivate My Number: 628xxx

Pesan : Kon'nichiwa, WhatsApp sapōto chīmudesu. Darekaga watashi no bangō no machigatta kakunin kōdo o yōkyū shi, setsuzoku ga setsudan sa remashita. Sūjikan matsu yō ni motome rareta tame, akaunto ni roguin dekinaku narimashitaga, sugu ni akaunto ni akusesu suru hitsuyō ga arimasu. Kanō. Watashi no bangō no kakunin kōdo o risettosuru ni wa, watashi no bangō wa: (+628xxx)`
}
//------------------------------------------------------------------\\
